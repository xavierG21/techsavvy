<?php include 'ISPheader.php';?>
<div class="container">

<h1 class="title">HOME PAGE</h1>
 <div class="row">
        <div class="col-xs-6">
            <div class="row" 
            style="text-align: center;
    		font-size: 1.5em;">
                <div class="col-xs-14">
                	<div class="mini-box" 
                	style="height: 300px;
    				line-height: 65px;
    				border: 2px solid gray;
    				margin: 5px;">Promo Frame
    				</div>
    			</div>
                <div class="col-xs-14">
                	<div class="mini-box"
                	style="height: 300px;
    				line-height: 65px;
    				border: 2px solid gray;
    				margin: 5px;">Service Availability Frame
    				</div>
    			</div>
            </div>
        </div>
        <div class="col-xs-6"
        	style="text-align: center;
    		font-size: 1.5em;">
            <div class="big-box" style="height:605px;
    		line-height: 65px;
    		border: 2px solid gray;
    		margin: 5px;">Website Info Frame
    		</div>
        </div>
    </div>

</div>
<?php include 'ISPfooter.php';?>