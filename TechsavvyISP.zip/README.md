# Hotel Management System

Motto: Home away from Home

# About Hotel management System

	Hotel management System is an App that allows you to book and order for a hotel room. It has some basic functions like logding and so on		`	

# Getting Started on Installation

1. Clone the repository
2. Copy the project into your local server directory such as htdocs for xammp, and www for lamp or mamp
3. Start your local server
4. Go to your browser `localhost/name-of-folder` to view the project.
5. That is localhost/HotelManagement




```
git clone <CLONE_URL>
```

Copy into folder such as C:\xampp\htdocs/HotelManagement

```
C:\xampp\htdocs/HotelManagement
```

```

Start the project
```

`Start Local Server`

Visit `https://localhost/HotelManagement` to view the project.

**NOTES:**

&mdash; After cloning you will see a folder 'db' go into the directory you will see the sql database file
&mdash; Import the file into the database. Enjoy

