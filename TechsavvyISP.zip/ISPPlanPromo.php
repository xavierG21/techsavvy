<?php include "include/config.php" ?>
<?php include 'header.php';?>

<div class="container">

<h2 style="text-align:center; color:#fff;">What type of service are you looking for?</h2>
<h4 style="text-align:center; color:#fff;">Are you looking for internet for your Promo or Plan?</h4>

<div class="col-sm-6 wowload fadeInUp"><div class="rooms"><img src="images/promo1.jpg" width="100%" height="20%" class="img-responsive"><div class="info"><h3>Type : Promo</h3><h3>Description:</h3><p>Promo Description</p>
    <p><h3>Price:</h3> $Promo Prices</p>
    <a href="ISPPromo.php" class="btn btn-default">Check Details Promo </a></div></div></div>
 
<div class="col-sm-6 wowload fadeInUp"><div class="rooms"><img src="images/plan1.png" width="150%" height="150%" class="img-responsive"><div class="info"><h3>Type : Plan</h3><h3>Description:</h3><p>Plan Description</p>
    <p><h3>Price:</h3> $Plan Prices</p>
    <a href="ISPPlan.php" class="btn btn-default">Check Details Plan </a></div></div></div>    


</div>  
</div>    



                     <div class="text-center">
                     <ul class="pagination">
                     <li class="disabled"><a href="#">«</a></li>
                     <li class="active"><a href="#">1 <span class="sr-only">(current)</span></a></li>
                     <li><a href="#">2</a></li>
                     <li><a href="#">3</a></li>
                     <li><a href="#">4</a></li>
                     <li><a href="#">5</a></li>
                     <li><a href="#">»</a></li>
                     </ul>
                     </div>


</div>
<?php include 'footer.php';?>