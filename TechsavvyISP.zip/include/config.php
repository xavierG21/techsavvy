<?php 

	//Define the password and username  and set the conncection paramaters
	$servername = "localhost";
	$password = "";
	$username = "root";
	$dbname = "reservation";
	$con = mysqli_connect($servername, $username, $password, $dbname);
	
 ?>